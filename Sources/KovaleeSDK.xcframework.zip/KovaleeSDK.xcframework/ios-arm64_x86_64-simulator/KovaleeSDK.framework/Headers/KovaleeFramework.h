//
//  KovaleeFramework.h
//  KovaleeFramework
//
//  Created by Filippo Tosetto on 19/04/2023.
//

#import <Foundation/Foundation.h>

//! Project version number for KovaleeFramework.
FOUNDATION_EXPORT double KovaleeFrameworkVersionNumber;

//! Project version string for KovaleeFramework.
FOUNDATION_EXPORT const unsigned char KovaleeFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KovaleeFramework/PublicHeader.h>


